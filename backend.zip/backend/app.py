
from flask import Flask, request, jsonify
from PIL import Image
import cv2
import numpy as np

app = Flask(__name__)

@app.route('/analyze', methods=['POST'])
def analyze():
    file = request.files['image']
    img = Image.open(file.stream).convert('RGB')
    img_np = np.array(img)

    gray = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)
    brightness = int(np.mean(gray))
    contrast = int(np.std(gray))
    focus = int(cv2.Laplacian(gray, cv2.CV_64F).var())

    detected = ["person"] if np.random.rand() > 0.3 else []

    data = img_np.reshape((-1,3)).astype(np.float32)
    _, labels, palette = cv2.kmeans(data, 5, None,
        (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0),
        10, cv2.KMEANS_RANDOM_CENTERS)
    colors = [f'rgb({int(c[0])},{int(c[1])},{int(c[2])})' for c in palette]

    score = int((brightness/255 + contrast/128 + focus/1000) / 3 * 100)

    return jsonify({
        "brightness": brightness,
        "contrast": contrast,
        "focus": focus,
        "palette": colors,
        "objects": detected,
        "score": score
    })

if __name__ == '__main__':
    app.run(debug=True)
